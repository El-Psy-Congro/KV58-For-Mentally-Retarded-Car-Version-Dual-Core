#ifndef _CODINGSWITCH_H
#define _CODINGSWITCH_H

int CodingSwitch(int channelSelection, u8 threshold);

#endif
